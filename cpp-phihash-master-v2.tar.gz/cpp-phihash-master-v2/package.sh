#!/bin/bash

# PhiHash项目打包脚本
# 排除.git目录，生成tar.gz并输出SHA1哈希

set -e  # 遇到错误立即退出

# 获取当前目录名作为包名
CURRENT_DIR=$(basename "$(pwd)")
ARCHIVE_NAME="${CURRENT_DIR}.tar.gz"

echo "🚀 开始打包PhiHash项目..."
echo "📁 当前目录: $(pwd)"
echo "📦 包名: $ARCHIVE_NAME"

# 检查是否存在.git目录
if [ -d ".git" ]; then
    echo "✅ 发现.git目录，将被排除"
else
    echo "ℹ️  未发现.git目录"
fi

# 如果已存在同名压缩包，询问是否覆盖
if [ -f "$ARCHIVE_NAME" ]; then
    echo "⚠️  压缩包 $ARCHIVE_NAME 已存在"
    read -p "是否覆盖? [y/N]: " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "❌ 用户取消操作"
        exit 1
    fi
    rm -f "$ARCHIVE_NAME"
fi

# 创建tar.gz包，排除.git目录
echo "📦 正在创建压缩包..."
tar --exclude='.git' \
    --exclude='*.tar.gz' \
    --exclude='*.tmp' \
    --exclude='build' \
    --exclude='cmake-build-*' \
    -czf "$ARCHIVE_NAME" \
    -C .. \
    "$(basename "$(pwd)")"

# 检查压缩包是否创建成功
if [ ! -f "$ARCHIVE_NAME" ]; then
    echo "❌ 压缩包创建失败！"
    exit 1
fi

# 获取文件大小
FILE_SIZE=$(du -h "$ARCHIVE_NAME" | cut -f1)
echo "✅ 压缩包创建成功！大小: $FILE_SIZE"

# 计算SHA1哈希
echo "🔐 正在计算SHA1哈希..."
SHA1_HASH=$(sha1sum "$ARCHIVE_NAME" | cut -d' ' -f1)

# 输出结果
echo ""
echo "🎉 打包完成！"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📦 文件名: $ARCHIVE_NAME"
echo "📏 大小:   $FILE_SIZE"
echo "🔐 SHA1:   $SHA1_HASH"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# # 可选：验证压缩包内容
# echo ""
# echo "📋 压缩包内容预览 (前20个文件):"
# tar -tzf "$ARCHIVE_NAME" | head -20
# TOTAL_FILES=$(tar -tzf "$ARCHIVE_NAME" | wc -l)
# echo "... 总共 $TOTAL_FILES 个文件/目录"

# 可选：创建校验文件
CHECKSUM_FILE="${ARCHIVE_NAME}.sha1"
echo "$SHA1_HASH  $ARCHIVE_NAME" > "$CHECKSUM_FILE"
echo "✅ 校验文件已创建: $CHECKSUM_FILE"

echo ""
echo "🔍 验证命令:"
echo "   sha1sum -c $CHECKSUM_FILE"
echo "🗂️  解压命令:"
echo "   tar -xzf $ARCHIVE_NAME"